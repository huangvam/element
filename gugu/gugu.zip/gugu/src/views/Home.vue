<template>
  <div class="home">1</div>
</template>

<script>
export default {
  name: 'Home'
}
</script>
